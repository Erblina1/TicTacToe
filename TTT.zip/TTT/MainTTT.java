import javax.swing.*;
public class MainTTT {
public static void main(String[] args)
{
TicTacToe t=new TicTacToe();
t.initializeBoard();
char player='X';
do{t.printBoard();
String s=new JOptionPane().showInputDialog("Enter coordinates for rows:");
int row=Integer.parseInt(s);
s=new JOptionPane().showInputDialog("Enter coordinates for columns:");
int column=Integer.parseInt(s);
if(t.empty(row,column))
{
JOptionPane.showMessageDialog(null,"That spot is taken.\n U should start the game from the start");
break;
}
t.setPlay(row,column,player);
if(t.checkTheWinner())
{t.printBoard();
JOptionPane.showMessageDialog(null,player+" won,Congratulations!");
break;}
if(t.draw())
{t.printBoard();
JOptionPane.showMessageDialog(null,"No one won.Play again!");
break;}
if(player=='X')
player='O';
else 
player='X';
}while(true);
}
}