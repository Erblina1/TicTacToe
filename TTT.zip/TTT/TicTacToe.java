public class TicTacToe
{private char board[][];
   private static final int rows=3;
   private static final int columns=3;
   
   // This is the constructor. It is responsible for ensuring the board gets initialized properly.
   public TicTacToe()
   {board=new char[rows][columns];
   }

  //This method will initialize the board variable such that all slots are empty.
   public void initializeBoard() {
      for(int i=0;i<rows;i++) {
         for(int j=0;j<columns;j++) {
            board[i][j]=' '; }
      }
   }
   
   public void setPlay(int i,int j,char player)
   {
      board[i][j]=player;
   }
   
   //This method checks if the spot is empty or taken
   public boolean empty(int i,int j){ 
      if(board[i][j] != ' '){
      return true;  
      }
      return false;
   }
   
   //This method checks if the game is a tie
   public boolean draw(){
      for ( int i = 0; i < rows; i++) {
         for (int j = 0; j < columns; j++) {
            if (board[i][j] == ' ') {
               return false; }
         } 
      }
      return true;
   }
   
   //This method checks if the game has a winner
   public boolean checkTheWinner() {
      boolean ok=false;
      for (int a = 0; a < 8; a++) {
         String line = null;
         switch (a) {
            case 0:
               line =""+ board[0][0] + board[0][1] + board[0][2];
               break;
            case 1:
               line =""+board[1][0] + board[1][1] + board[1][2];
               break;
            case 2:
               line =""+ board[2][0] + board[2][1] + board[2][2];
               break;
            case 3:
               line =""+ board[0][0] + board[1][0] + board[2][0];
               break;
            case 4:
               line =""+ board[0][1] + board[1][1] + board[2][1];
               break;
            case 5:
               line =""+ board[0][2] + board[1][2] + board[2][2];
               break;
            case 6:
               line =""+ board[0][0] + board[1][1] + board[2][2];
               break;
            case 7:
               line =""+ board[0][2] + board[1][1] + board[2][0];
               break;
         }
         if (line.equals("XXX")|| line.equals("OOO")){
            ok=true;
         }
      }
      return ok;
   }
   
   //This method will print the Tic-Tac-Toe board
   public void printBoard()
   {   
      System.out.println("-------------");
      System.out.println("| " + board[0][0] + " | " + board[0][1] + " | " + board[0][2] + " |");
      System.out.println("|-----------|");
      System.out.println("| " + board[1][0] + " | " + board[1][1] + " | " + board[1][2] + " |");
      System.out.println("|-----------|");
      System.out.println("| " + board[2][0] + " | " + board[2][1] + " | " + board[2][2] + " |");
      System.out.println("-------------");
      
   }
}
